package com.kms.test.results;

public enum WriteResult {
    FAILURE,
    SUCCESS
}

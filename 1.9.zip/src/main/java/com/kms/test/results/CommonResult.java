package com.kms.test.results;

public enum CommonResult implements Result{
    FAILURE,
    SUCCESS
}
